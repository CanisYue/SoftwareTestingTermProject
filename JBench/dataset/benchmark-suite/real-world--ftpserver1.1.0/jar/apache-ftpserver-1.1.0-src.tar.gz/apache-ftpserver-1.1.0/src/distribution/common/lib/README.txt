Binary Distribution
--------------------
You can keep your other jar files here. All the jar files in this directory 
will be available to the FTP server.
